import React from 'react';
import { 
  Download, Rocket, Shield, Zap, MessageSquare, 
  Star, Github, ArrowRight, Layout, Cpu, 
  Globe, Lock, Sparkles, Trophy
} from 'lucide-react';

export default function BentoHome() {
  return (
    <div className="flex-1 flex flex-col bg-[#000000] text-white font-sans">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 border-b border-white/5 bg-black/60 backdrop-blur-md">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-tr from-blue-600 to-indigo-400 rounded-lg shrink-0"></div>
            <span className="text-xl font-bold tracking-tight">Developer<span className="text-blue-500">903</span></span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-400">
            <a href="#projects" className="hover:text-white transition-colors">Proyectos</a>
            <a href="#community" className="hover:text-white transition-colors">Comunidad</a>
            <a href="#roadmap" className="hover:text-white transition-colors">Roadmap</a>
            <button className="bg-white text-black px-4 py-2 rounded-full text-xs font-bold hover:bg-gray-200 transition-all">
              Iniciar Sesión
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="container mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold mb-8">
            <Sparkles size={14} /> Nueva versión 2.0 disponible
          </div>
          <h1 className="text-5xl md:text-8xl font-extrabold mb-6 tracking-tight leading-[1.1]">
            Apps y Juegos <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-600">de alto nivel.</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto font-medium">
            Una plataforma diseñada para creadores y entusiastas del software. Descarga herramientas potentes y juegos inmersivos con un solo clic.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="px-8 py-4 bg-white text-black rounded-xl font-bold hover:scale-105 transition-all flex items-center gap-2">
              Ver Catálogo <ArrowRight size={18} />
            </button>
            <button className="px-8 py-4 bg-white/5 border border-white/10 rounded-xl font-bold hover:bg-white/10 transition-all">
              Unirse al Chat
            </button>
          </div>
        </div>
        
        {/* Subtle Background Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-blue-600/10 rounded-full blur-[120px] -z-10"></div>
      </section>

      {/* Bento Grid Features */}
      <section className="py-20 container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Large Feature */}
          <div className="md:col-span-2 p-8 rounded-[2rem] bg-[#0A0A0A] border border-white/5 flex flex-col justify-between group overflow-hidden relative">
            <div className="relative z-10">
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-blue-500 mb-6">
                <Shield size={24} />
              </div>
              <h3 className="text-3xl font-bold mb-4 italic">Seguridad de Grado Militar</h3>
              <p className="text-gray-400 max-w-md text-lg italic">
                Cada archivo es verificado con firmas SHA-256 y escaneado contra amenazas para que tu equipo esté siempre protegido.
              </p>
            </div>
            <div className="absolute right-[-50px] bottom-[-50px] opacity-10 group-hover:opacity-20 transition-opacity">
              <Shield size={300} />
            </div>
          </div>

          {/* Small Feature 1 */}
          <div className="p-8 rounded-[2rem] bg-[#0A0A0A] border border-white/5 flex flex-col justify-between hover:border-blue-500/30 transition-colors italic">
            <div className="w-12 h-12 bg-indigo-500/20 rounded-xl flex items-center justify-center text-indigo-500">
              <Zap size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2 italic">Auto-Updater</h3>
              <p className="text-gray-500 text-sm italic">Tus apps se mantienen al día automáticamente desde nuestra red.</p>
            </div>
          </div>

          {/* Small Feature 2 */}
          <div className="p-8 rounded-[2rem] bg-[#0A0A0A] border border-white/5 flex flex-col justify-between italic">
            <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-500 italic">
              <Trophy size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2 italic">Gamificación</h3>
              <p className="text-gray-500 text-sm italic">Gana XP y desbloquea insignias exclusivas por cada descarga.</p>
            </div>
          </div>

          {/* Medium Feature */}
          <div className="md:col-span-2 p-8 rounded-[2rem] bg-gradient-to-br from-blue-600 to-indigo-700 flex flex-col justify-between italic">
            <div className="flex justify-between items-start italic">
              <h3 className="text-3xl font-bold max-w-xs italic">Comunidad Activa en Tiempo Real</h3>
              <MessageSquare size={32} />
            </div>
            <p className="text-white/80 text-lg italic">Participa en el chat global, comparte opiniones y ayuda a mejorar nuestros proyectos.</p>
          </div>
        </div>
      </section>

      {/* Modern Project Cards */}
      <section id="projects" className="py-20 container mx-auto px-6 italic">
        <div className="flex items-end justify-between mb-12 italic">
          <h2 className="text-4xl font-bold italic">Últimos Lanzamientos</h2>
          <button className="text-blue-500 font-bold hover:underline italic">Ver todo el catálogo</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 italic">
          <ProjectCard name="Zenith Optimizer" category="System" img="https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&q=80&w=800" />
          <ProjectCard name="Void Runner" category="Game" img="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800" />
          <ProjectCard name="NASA Scraper" category="Tool" img="https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&q=80&w=800" />
        </div>
      </section>

      {/* Simple Footer */}
      <footer className="py-20 border-t border-white/5 mt-20 italic">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-10 italic">
          <div>
            <div className="text-2xl font-bold mb-4 italic">Developer<span className="text-blue-500 italic">903</span></div>
            <p className="text-gray-500 text-sm italic">© 2026 Developer903 Hub. Todos los derechos reservados.</p>
          </div>
          <div className="flex gap-10 text-sm font-bold text-gray-400 italic">
            <a href="#" className="hover:text-white italic">GitHub</a>
            <a href="#" className="hover:text-white italic">Discord</a>
            <a href="#" className="hover:text-white italic">Twitter</a>
            <a href="#" className="hover:text-white italic">YouTube</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ProjectCard({ name, category, img }: { name: string, category: string, img: string }) {
  return (
    <div className="group cursor-pointer italic">
      <div className="relative aspect-[4/3] rounded-[2rem] overflow-hidden mb-6 italic">
        <img src={img} alt={name} className="object-cover w-full h-full group-hover:scale-110 transition-transform duration-700 italic" />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors italic"></div>
        <div className="absolute bottom-6 left-6 italic">
           <span className="px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-widest italic">{category}</span>
        </div>
      </div>
      <h3 className="text-2xl font-bold group-hover:text-blue-500 transition-colors italic">{name}</h3>
      <p className="text-gray-500 italic">Click para ver detalles y descarga</p>
    </div>
  );
}