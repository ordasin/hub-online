import { useState, useEffect, useRef } from 'react';
import { Row, Col, Badge, Nav, Navbar, Button, Modal, Form, Toast, ToastContainer, Card } from 'react-bootstrap';
import { 
  Terminal, BarChart3, Star, CheckCircle2,
  MessageCircle, Code2, ShieldCheck, Zap, 
  Rocket, User, LogIn, LogOut, Settings,
  Plus, Share2, Globe, Smartphone, Bell, Clock, Play, Send, Download, MessageSquare, Activity
} from 'lucide-react';
import { Peer } from 'peerjs';
import { openDB } from 'idb';

// --- DATABASE CONFIG ---
const DB_NAME = 'dev903_formal_db';
const initDB = async () => {
  return openDB(DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('my_projects')) db.createObjectStore('my_projects', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('community_projects')) db.createObjectStore('community_projects', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('posts')) db.createObjectStore('posts', { keyPath: 'id' });
    },
  });
};

const OFFICIAL_PROJECTS = [
  { id: 1, title: "903 Optimizer", version: "v1.2.5", status: 'Stable', type: 'System Utility', desc: "Arquitectura de optimización para la reducción de latencia sistémica en entornos Windows.", image: "/optimizer_full.png", downloadUrl: "/Developer903_Optimizer.zip" },
  { id: 2, title: "OrdasinTools", version: "v1.0.0", status: 'Stable', type: 'Core Scripts', desc: "Infraestructura de scripts para el endurecimiento y eficiencia de sistemas Linux.", image: "https://images.unsplash.com/photo-1605142859862-978be7eba909?auto=format&fit=crop&q=80&w=1200", downloadUrl: "#" }
];

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [user, setUser] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [toasts, setToasts] = useState<any[]>([]);
  const [peerId, setPeerId] = useState('');
  const [targetPeerId, setTargetPeerId] = useState('');
  const [chatMsgs, setChatMsgs] = useState<any[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const peerInstance = useRef<any>(null);
  const connInstance = useRef<any>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);

  useEffect(() => {
    const load = async () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const db = await initDB();
      setPosts(await db.getAll('posts'));
      const savedUser = localStorage.getItem('ordasin_user');
      if (savedUser) setupIdentity(JSON.parse(savedUser));
    };
    load();
  }, [activeSection]);

  const addToast = (msg: string) => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, msg }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3000);
  };

  const setupIdentity = (identity: any) => {
    setUser(identity);
    localStorage.setItem('ordasin_user', JSON.stringify(identity));
    if (!peerInstance.current) {
      const p = new Peer(identity.userId);
      p.on('open', (id) => setPeerId(id));
      p.on('connection', (conn) => {
        connInstance.current = conn;
        setIsConnected(true);
        addToast("SESIÓN P2P VINCULADA");
        conn.on('data', (data: any) => setChatMsgs(prev => [...prev, { from: conn.peer, text: data.text || data }]));
      });
      peerInstance.current = p;
    }
  };

  const handleLogin = (e: any) => {
    e.preventDefault();
    const name = e.target.elements[0].value || 'Tester';
    const identity = { userId: 'node_' + Math.random().toString(36).substring(2, 9), name };
    setupIdentity(identity);
    setShowAuthModal(false);
    addToast("IDENTIDAD TÉCNICA ACTIVADA");
  };

  const connectToPeer = () => {
    if (!targetPeerId || !peerInstance.current) return;
    const conn = peerInstance.current.connect(targetPeerId);
    connInstance.current = conn;
    conn.on('open', () => {
      setIsConnected(true);
      addToast("NODO VINCULADO");
    });
    conn.on('data', (data: any) => setChatMsgs(prev => [...prev, { from: targetPeerId, text: data.text || data }]));
  };

  const sendChatMessage = (text: string) => {
    if (!text || !connInstance.current) return;
    connInstance.current.send({ type: 'CHAT', text });
    setChatMsgs([...chatMsgs, { from: peerId, text }]);
  };

  return (
    <div className="bg-formal min-vh-100 text-slate-200 font-sans full-page-wrapper">
      <div className="technical-grid"></div>
      
      <ToastContainer position="bottom-start" className="p-4" style={{ zIndex: 10000 }}>
        {toasts.map(t => (
          <Toast key={t.id} className="bg-slate-800 text-blue-400 border border-blue-900 rounded-0 shadow-xl mb-2">
            <Toast.Body className="smallest fw-bold d-flex align-items-center gap-2">
              <ShieldCheck size={14} /> {t.msg}
            </Toast.Body>
          </Toast>
        ))}
      </ToastContainer>

      <Navbar expand="lg" className="navbar-formal py-0 sticky-top border-bottom border-slate-800 bg-slate-900">
        <div className="w-100 d-flex align-items-center px-4 py-2">
          <Navbar.Brand onClick={() => setActiveSection('home')} className="fw-bold fs-6 d-flex align-items-center gap-2 cursor-pointer m-0 text-white tracking-tight">
            <div className="brand-square"></div> DEVELOPER 903
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-nav" className="ms-auto border-0 shadow-none" />
          <Navbar.Collapse id="basic-nav">
            <Nav className="ms-auto align-items-center">
              {['home', 'projects', 'lab'].map(id => (
                <Nav.Link key={id} onClick={() => setActiveSection(id)} className={`nav-link-formal ${activeSection === id ? 'active' : ''}`}>
                  {id === 'home' ? 'OVERVIEW' : id.toUpperCase()}
                </Nav.Link>
              ))}
              {user ? (
                <div className="ms-lg-4 px-3 py-1 border border-slate-700 bg-slate-800 smallest fw-bold text-blue-400">NODE: @{user.name.toUpperCase()}</div>
              ) : (
                <Button variant="outline-blue" onClick={() => setShowAuthModal(true)} className="ms-lg-4 rounded-0 px-4 py-2 smallest fw-bold border-blue-900 text-blue-400">SIGN IN</Button>
              )}
            </Nav>
          </Navbar.Collapse>
        </div>
      </Navbar>

      <main className="w-100 animate-in">
        {activeSection === 'home' && (
          <div className="w-100">
            <header className="hero-formal border-bottom border-slate-800 p-5 py-lg-9 text-center">
               <Badge bg="transparent" className="text-blue-500 border border-blue-900 mb-4 rounded-0 px-3 py-2 smallest tracking-widest uppercase fw-black">Engineering Studio Portfolio</Badge>
               <h1 className="display-2 fw-bold tracking-tighter mb-4 text-white uppercase">Sistemas de Alto Rendimiento.</h1>
               <p className="fs-5 text-slate-400 max-w-2xl mx-auto mb-5">Desarrollo de infraestructura de software y optimización técnica dirigida por Ordasin.</p>
               <div className="d-flex gap-3 justify-content-center">
                  <Button variant="blue-formal" className="rounded-0 px-5 py-3 fw-bold smallest" onClick={() => setActiveSection('projects')}>REPOSITORIO</Button>
                  <Button variant="outline-slate" className="rounded-0 px-5 py-3 fw-bold smallest border-slate-700" onClick={() => setActiveSection('lab')}>SOCIAL LAB</Button>
               </div>
            </header>
            <section className="p-5 border-bottom border-slate-800 bg-slate-900-50">
               <Row className="g-5 align-items-center justify-content-center">
                  <Col lg={6}>
                    <h6 className="smallest fw-bold text-blue-500 mb-3 uppercase tracking-widest">Technical Briefing</h6>
                    <h2 className="h2 fw-bold tracking-tighter mb-4 text-white">NUESTRO ENFOQUE</h2>
                    <p className="fs-6 text-slate-400 mb-0 line-height-lg">Esta plataforma centraliza los proyectos de ingeniería de Ordasin. Cada herramienta es un prototipo funcional diseñado para resolver cuellos de botella mediante ajustes de bajo nivel.</p>
                  </Col>
                  <Col lg={5}>
                     <div className="p-4 border border-slate-800 bg-slate-900">
                        <div className="d-flex align-items-center gap-3 mb-4"><Activity size={18} className="text-blue-500" /><span className="smallest fw-bold uppercase tracking-widest text-white">Protocolo de Validación</span></div>
                        <div className="d-grid gap-3 smallest text-slate-400">
                           <div className="d-flex justify-content-between border-bottom border-slate-800 pb-2"><span>Deployment</span> <span className="text-white">Direct Access</span></div>
                           <div className="d-flex justify-content-between"><span>Architecture</span> <span className="text-white">Zero Backend</span></div>
                        </div>
                     </div>
                  </Col>
               </Row>
            </section>
          </div>
        )}

        {activeSection === 'projects' && (
          <div className="animate-in w-100 p-5">
             <div className="mb-5 border-bottom border-slate-800 pb-4"><h2 className="display-6 fw-bold text-white uppercase tracking-tighter m-0">Repositorio Oficial</h2><p className="smallest text-slate-500 mt-2 tracking-widest uppercase">Software de grado técnico</p></div>
             {OFFICIAL_PROJECTS.map(p => (
                <div key={p.id} className="p-5 border border-slate-800 bg-slate-900 mb-4 transition hover-border-blue">
                   <Row className="g-5 align-items-center">
                      <Col lg={3}><img src={p.image} className="w-100 border border-slate-800" alt={p.title}/></Col>
                      <Col lg={9}>
                         <div className="d-flex align-items-center gap-3 mb-2"><h3 className="h3 fw-bold text-white uppercase m-0">{p.title}</h3><Badge bg="transparent" className="border border-blue-900 text-blue-500 rounded-0 smallest px-2 py-1">{p.version}</Badge></div>
                         <p className="small text-slate-400 mb-4 line-height-lg">{p.desc}</p>
                         <Button variant="blue-formal" as="a" href={p.downloadUrl} download className="rounded-0 px-5 py-2 smallest fw-bold">DOWNLOAD ASSETS</Button>
                      </Col>
                   </Row>
                </div>
             ))}
          </div>
        )}

        {activeSection === 'lab' && (
          <div className="animate-in w-100 p-5">
             <header className="mb-5 border-bottom border-slate-800 pb-4"><h2 className="display-6 fw-bold text-white uppercase tracking-tighter m-0">Social Lab <span className="text-blue-500">Node</span></h2></header>
             <Row className="g-4">
                <Col lg={4}>
                   <div className="p-4 border border-slate-800 bg-slate-900 mb-4">
                      <h6 className="smallest fw-bold text-slate-500 uppercase mb-3">Identity Signature</h6>
                      <div className="p-3 bg-black border border-slate-800 font-monospace smallest text-blue-400 text-break mb-3">{peerId || 'Awaiting Auth...'}</div>
                      <Button variant="outline-slate" className="w-100 smallest fw-bold rounded-0 border-slate-700" onClick={() => { navigator.clipboard.writeText(peerId); addToast("ID COPIADO"); }}>COPY SIGNATURE</Button>
                   </div>
                   <div className="p-4 border border-slate-800 bg-slate-900">
                      <h6 className="smallest fw-bold text-slate-500 uppercase mb-3">Remote Link</h6>
                      <Form.Control className="form-input-formal mb-3 smallest" placeholder="Destination ID..." value={targetPeerId} onChange={e => setTargetPeerId(e.target.value)} />
                      <Button variant="blue-formal" className="w-100 py-2 smallest fw-bold rounded-0" onClick={connectToPeer} disabled={isConnected}>LINK NODES</Button>
                   </div>
                </Col>
                <Col lg={8}>
                   <div className="chat-box-formal border border-slate-800 bg-slate-900 d-flex flex-column" style={{height: '550px'}}>
                      <div className="p-3 border-bottom border-slate-800 smallest fw-bold uppercase tracking-widest text-slate-500">Status: {isConnected ? "Linked" : "Standby"}</div>
                      <div className="flex-fill p-4 overflow-auto d-flex flex-column gap-3">
                         {chatMsgs.map((m, i) => (
                            <div key={i} className={`d-flex ${m.from === peerId ? 'justify-content-end' : 'justify-content-start'}`}>
                               <div className={`p-3 smallest fw-bold border ${m.from === peerId ? 'bg-blue-formal-dark border-blue-900 text-white' : 'bg-slate-800 border-slate-700 text-slate-300'}`} style={{maxWidth: '75%'}}>{m.text}</div>
                            </div>
                         ))}
                      </div>
                      <div className="p-3 border-top border-slate-800">
                         <Form.Control className="form-input-formal border-0 bg-transparent smallest" placeholder="Send technical data..." onKeyPress={(e:any) => { if(e.key === 'Enter') { sendChatMessage(e.target.value); e.target.value = ''; } }} disabled={!isConnected} />
                      </div>
                   </div>
                </Col>
             </Row>
          </div>
        )}
      </main>

      <Modal show={showAuthModal} onHide={() => setShowAuthModal(false)} centered contentClassName="rounded-0 border border-slate-800 bg-slate-900 text-white">
        <div className="p-5 text-center"><h4 className="fw-bold mb-4 uppercase tracking-tighter text-white">System Auth</h4><Form onSubmit={handleLogin}><Form.Control className="form-input-formal mb-3" placeholder="USERNAME" required /><Button variant="blue-formal" type="submit" className="w-100 py-3 rounded-0 smallest fw-bold">GENERATE ID</Button></Form></div>
      </Modal>

      <footer className="w-100 p-5 mt-auto border-top border-slate-800 bg-slate-900 text-center text-slate-600">
         <div className="fw-bold smallest uppercase tracking-widest">Developer 903 Architecture Studio © 2026</div>
      </footer>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #0f172a; color: #94a3b8; margin: 0; padding: 0; overflow-x: hidden; width: 100vw; }
        .full-page-wrapper { width: 100vw; position: relative; }
        .technical-grid { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-image: linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px); background-size: 40px 40px; z-index: 0; pointer-events: none; }
        .smallest { font-size: 0.65rem; letter-spacing: 0.1em; }
        .uppercase { text-transform: uppercase; }
        .navbar-formal { background-color: #0f172a; z-index: 1000; }
        .brand-square { width: 12px; height: 12px; background: #2563eb; border-radius: 2px; }
        .nav-link-formal { color: #64748b; font-size: 0.7rem; font-weight: 700; padding: 1.5rem 1.2rem !important; transition: 0.3s; border-left: 1px solid rgba(255,255,255,0.03); }
        .nav-link-formal:hover, .nav-link-formal.active { color: #fff !important; background: rgba(255,255,255,0.02); }
        .btn-blue-formal { background-color: #2563eb; color: white; border: none; transition: 0.2s; }
        .btn-blue-formal:hover { background-color: #1d4ed8; color: white; }
        .bg-blue-formal-dark { background-color: #1e3a8a; }
        .form-input-formal { border-radius: 0; border: 1px solid #1e293b; padding: 1rem; font-size: 0.75rem; background: #0f172a; color: white; }
        .form-input-formal:focus { border-color: #2563eb; background: #1e293b; color: white; box-shadow: none; }
        .hero-formal { min-height: 70vh; display: flex; align-items: center; justify-content: center; background: radial-gradient(circle at center, #1e293b 0%, #0f172a 80%); position: relative; }
        .py-lg-9 { padding-top: 140px; padding-bottom: 120px; }
        .animate-in { animation: fadeIn 0.5s ease-out; position: relative; z-index: 1; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .hover-border-blue:hover { border-color: #2563eb !important; }
        .cursor-pointer { cursor: pointer; }
        @media (max-width: 991px) { .nav-link-formal { border-left: none; border-bottom: 1px solid rgba(255,255,255,0.05); } }
      `}</style>
    </div>
  );
}

export default App;