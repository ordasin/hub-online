declare module 'webtorrent';
