"use client";

import React, { useState, useEffect } from 'react';
import { Send, Terminal, User as UserIcon } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  user: {
    name: string;
    level: number;
    image?: string;
  };
  createdAt: string;
}

export default function NexusChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');

  // Mock data for initial UI build
  useEffect(() => {
    setMessages([
      {
        id: '1',
        content: '¡Bienvenido al Nexus Chat de Nebula Core!',
        user: { name: 'SYSTEM', level: 99 },
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        content: '¿Alguien ha probado el nuevo Zenith Optimizer?',
        user: { name: 'AlphaUser', level: 5 },
        createdAt: new Date().toISOString(),
      }
    ]);
  }, []);

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    const newMessage: Message = {
      id: Date.now().toString(),
      content: input,
      user: { name: 'You', level: 1 },
      createdAt: new Date().toISOString(),
    };
    
    setMessages([...messages, newMessage]);
    setInput('');
  };

  return (
    <div className="flex flex-col h-[600px] border border-white/5 bg-black/40 backdrop-blur-md rounded-xl overflow-hidden">
      <div className="p-4 border-b border-white/5 bg-white/[0.02] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal size={18} className="text-cyan-500" />
          <span className="font-black uppercase tracking-widest text-xs italic">Nexus_Chat.exe</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-[10px] font-bold text-white/40 uppercase">12 Nodes Online</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
        {messages.map((msg) => (
          <div key={msg.id} className="flex gap-4 group">
            <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center border border-white/10 shrink-0">
              <UserIcon size={20} className="text-white/40" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-cyan-500 uppercase italic">{msg.user.name}</span>
                <span className="text-[8px] px-1 bg-white/10 rounded text-white/60 font-bold">LVL {msg.user.level}</span>
                <span className="text-[8px] text-white/20">{new Date(msg.createdAt).toLocaleTimeString()}</span>
              </div>
              <p className="text-sm text-white/80 leading-relaxed bg-white/[0.03] p-3 rounded-tr-xl rounded-br-xl rounded-bl-xl border border-white/5">
                {msg.content}
              </p>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={sendMessage} className="p-4 bg-white/[0.02] border-t border-white/5 flex gap-4">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message into the matrix..."
          className="flex-1 bg-black/50 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
        />
        <button type="submit" className="p-3 bg-cyan-500 text-black hover:bg-cyan-400 transition-colors">
          <Send size={18} />
        </button>
      </form>
    </div>
  );
}
