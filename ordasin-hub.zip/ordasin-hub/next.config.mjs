/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export', // Esto genera archivos HTML/CSS/JS puros
  images: {
    unoptimized: true, // Necesario para exportación estática
  },
};

export default nextConfig;