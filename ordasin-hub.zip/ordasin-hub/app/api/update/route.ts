import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const projectId = searchParams.get('id');
  const currentVersion = searchParams.get('v');

  if (!projectId || !currentVersion) {
    return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
  }

  try {
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      select: {
        version: true,
        fileUrl: true,
        checksum: true,
        changelogs: {
          orderBy: { createdAt: 'desc' },
          take: 1
        }
      }
    });

    if (!project) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    const updateAvailable = project.version !== currentVersion;

    return NextResponse.json({
      updateAvailable,
      latestVersion: project.version,
      downloadUrl: project.fileUrl,
      checksum: project.checksum,
      changelog: project.changelogs[0]?.changes || 'No changelog available'
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
