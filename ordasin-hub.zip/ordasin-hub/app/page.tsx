import React from 'react';
import { 
  Download, Rocket, Shield, Zap, MessageSquare, 
  Star, Github, Terminal, Database, Activity, 
  ShieldCheck, Cpu, Globe, Lock
} from 'lucide-react';

export default function NebulaHome() {
  return (
    <div className="flex-1 flex flex-col bg-[#050505] text-white selection:bg-cyan-500/30">
      {/* HUD / Navigation */}
      <nav className="fixed top-0 w-full z-50 border-b border-white/5 bg-black/50 backdrop-blur-xl">
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-500 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.5)]">
              <Terminal size={24} className="text-black" />
            </div>
            <span className="text-2xl font-black tracking-tighter uppercase italic">Nebula<span className="text-cyan-500">Core</span></span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium tracking-widest uppercase text-white/50">
            <a href="#projects" className="hover:text-cyan-400 transition-colors">Archive</a>
            <a href="#community" className="hover:text-cyan-400 transition-colors">Nexus Chat</a>
            <a href="#security" className="hover:text-cyan-400 transition-colors">Security</a>
            <a href="#admin" className="px-4 py-2 border border-cyan-500/50 text-cyan-400 rounded-md hover:bg-cyan-500/10 transition-all">Control Panel</a>
          </div>
        </div>
      </nav>

      {/* Hero: The Singularity */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] bg-cyan-500/10 rounded-full blur-[120px] animate-pulse"></div>
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-cyan-500/30 bg-cyan-500/5 text-cyan-400 text-xs font-bold uppercase tracking-[0.2em] mb-8 animate-bounce">
            <Activity size={14} /> System Online: v4.0.2
          </div>
          <h1 className="text-7xl md:text-9xl font-black mb-6 tracking-tighter leading-none">
            UNLEASH THE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600">SOFTWARE.</span>
          </h1>
          <p className="text-lg md:text-xl text-white/40 mb-12 max-w-3xl mx-auto font-light leading-relaxed">
            Nebula Core es el epicentro de mis creaciones digitales. Apps de alto rendimiento, juegos experimentales y herramientas de sistema, todo con verificación de integridad y despliegue ultra-rápido.
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <button className="group relative px-10 py-5 bg-white text-black font-black uppercase tracking-widest text-sm overflow-hidden transition-all hover:pr-14">
              <span className="relative z-10">Access Archive</span>
              <Rocket size={20} className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all" />
            </button>
            <button className="px-10 py-5 border border-white/10 hover:border-cyan-500/50 transition-all font-black uppercase tracking-widest text-sm bg-white/5 backdrop-blur-sm">
              Community Nexus
            </button>
          </div>
        </div>

        {/* Scrolling Stats Bar */}
        <div className="absolute bottom-0 w-full border-t border-white/5 bg-black/80 backdrop-blur-md py-4">
          <div className="container mx-auto px-6 flex justify-around items-center opacity-50 text-[10px] font-bold tracking-[0.3em] uppercase">
            <div className="flex items-center gap-2"><Globe size={12}/> Global Nodes: 12</div>
            <div className="flex items-center gap-2"><Database size={12}/> Data Flow: 4.2TB</div>
            <div className="flex items-center gap-2"><Cpu size={12}/> Uptime: 99.9%</div>
            <div className="flex items-center gap-2"><Lock size={12}/> Secure Downloads: 25k+</div>
          </div>
        </div>
      </section>

      {/* Grid: Essential Capabilities */}
      <section className="py-32 bg-[#080808]">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-1">
            <CapabilityCard 
              icon={<ShieldCheck size={32} className="text-cyan-500" />}
              title="SHA-256 Verified"
              desc="Cada binario es analizado y firmado. Integridad garantizada al 100% mediante algoritmos de encriptación militar."
            />
            <CapabilityCard 
              icon={<Zap size={32} className="text-yellow-500" />}
              title="Hyper-Update"
              desc="Mis apps se comunican con el Core en tiempo real. Recibe parches críticos y nuevas funciones sin reinstalar."
            />
            <CapabilityCard 
              icon={<MessageSquare size={32} className="text-purple-500" />}
              title="Nexus Chat"
              desc="Sistema de comunicación encriptado para usuarios. Comparte feedback, reporta bugs o pide nuevas features."
            />
          </div>
        </div>
      </section>

      {/* Project Matrix */}
      <section id="projects" className="py-32 container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-6">
          <div>
            <h2 className="text-5xl font-black uppercase italic tracking-tighter">Software <span className="text-cyan-500">Matrix</span></h2>
            <p className="text-white/40 mt-4 max-w-md uppercase text-xs tracking-widest font-bold">Explora las últimas entradas del repositorio</p>
          </div>
          <div className="flex gap-4">
             <button className="p-4 border border-white/10 hover:border-cyan-500 transition-colors">APPS</button>
             <button className="p-4 border border-white/10 hover:border-cyan-500 transition-colors text-cyan-500 border-cyan-500/50">GAMES</button>
             <button className="p-4 border border-white/10 hover:border-cyan-500 transition-colors">TOOLS</button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          <ProjectNode name="Zenith Optimizer" version="v2.1" type="System" />
          <ProjectNode name="Void Runner 3D" version="Alpha" type="Game" />
          <ProjectNode name="Pulse Scraper" version="v1.0" type="Tool" />
        </div>
      </section>

      {/* Global Terminal / Footer */}
      <footer className="mt-auto border-t border-white/5 bg-black py-20">
        <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <div className="text-3xl font-black uppercase italic mb-6 tracking-tighter">Nebula<span className="text-cyan-500">Core</span></div>
            <p className="text-white/40 max-w-sm text-sm leading-relaxed mb-8">
              La infraestructura definitiva para el despliegue de software independiente. 
              Seguridad, velocidad y comunidad unidas en una sola red.
            </p>
            <div className="flex gap-4">
              <div className="w-10 h-10 border border-white/10 flex items-center justify-center hover:text-cyan-500 cursor-pointer transition-colors"><Github size={20}/></div>
              <div className="w-10 h-10 border border-white/10 flex items-center justify-center hover:text-cyan-500 cursor-pointer transition-colors"><Terminal size={20}/></div>
            </div>
          </div>
          <div>
            <h4 className="font-black uppercase tracking-widest text-xs mb-6 text-cyan-500">Resources</h4>
            <ul className="space-y-4 text-sm text-white/50">
              <li className="hover:text-white cursor-pointer transition-colors">Documentation</li>
              <li className="hover:text-white cursor-pointer transition-colors">API Reference</li>
              <li className="hover:text-white cursor-pointer transition-colors">Brand Assets</li>
            </ul>
          </div>
          <div>
            <h4 className="font-black uppercase tracking-widest text-xs mb-6 text-cyan-500">Legal</h4>
            <ul className="space-y-4 text-sm text-white/50">
              <li className="hover:text-white cursor-pointer transition-colors">Terms of Service</li>
              <li className="hover:text-white cursor-pointer transition-colors">Privacy Policy</li>
              <li className="hover:text-white cursor-pointer transition-colors">EULA</li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}

function CapabilityCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="p-12 border border-white/5 hover:border-white/10 transition-all bg-gradient-to-b from-white/[0.02] to-transparent">
      <div className="mb-6">{icon}</div>
      <h3 className="text-2xl font-black uppercase tracking-tighter mb-4 italic">{title}</h3>
      <p className="text-white/40 leading-relaxed text-sm">{desc}</p>
    </div>
  );
}

function ProjectNode({ name, version, type }: { name: string, version: string, type: string }) {
  return (
    <div className="group relative">
      <div className="aspect-video bg-white/[0.03] border border-white/5 mb-6 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        <div className="absolute top-4 left-4 px-2 py-1 bg-black/50 text-[10px] font-bold tracking-widest uppercase border border-white/10">{type}</div>
        <div className="w-full h-full flex items-center justify-center opacity-20 group-hover:opacity-100 transition-all duration-700 group-hover:scale-110">
          <Cpu size={64} className="text-white" />
        </div>
      </div>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-black uppercase italic tracking-tighter group-hover:text-cyan-400 transition-colors">{name}</h3>
          <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] mt-1">{version} // STABLE RELEASE</p>
        </div>
        <button className="p-3 border border-white/10 hover:bg-white hover:text-black transition-all">
          <Download size={18} />
        </button>
      </div>
    </div>
  );
}
