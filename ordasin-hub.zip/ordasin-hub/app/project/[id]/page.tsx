import React from 'react';
import { 
  Download, ShieldCheck, Clock, Star, 
  MessageSquare, BookOpen, Share2, AlertTriangle,
  ChevronRight, ExternalLink, HardDrive, Cpu
} from 'lucide-react';
import NexusChat from '@/components/NexusChat';

export default function ProjectDetail({ params }: { params: { id: string } }) {
  // En un caso real, aquí haríamos fetch del proyecto desde Prisma
  const project = {
    name: "Zenith Optimizer",
    version: "v2.1.0",
    type: "System Tool",
    description: "La herramienta definitiva para optimizar el rendimiento de Windows, limpiar registros y gestionar procesos de alta prioridad en tiempo real.",
    checksum: "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    size: "42.5 MB",
    downloads: "1,240",
    lastUpdate: "2026-02-01",
    stars: 89
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white pt-32 pb-20 px-6">
      <div className="container mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12">
        
        {/* Left Column: Info & Download */}
        <div className="lg:col-span-2 space-y-12">
          {/* Header */}
          <div className="flex flex-col md:flex-row gap-8 items-start">
            <div className="w-32 h-32 bg-cyan-500 rounded-3xl flex items-center justify-center shadow-[0_0_50px_rgba(6,182,212,0.3)] shrink-0">
              <Cpu size={64} className="text-black" />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-xs font-bold uppercase tracking-[0.3em] text-cyan-500">{project.type}</span>
                <span className="text-xs font-bold text-white/20">//</span>
                <span className="text-xs font-bold uppercase tracking-[0.3em] text-white/40">{project.version}</span>
              </div>
              <h1 className="text-5xl font-black uppercase tracking-tighter italic mb-4">{project.name}</h1>
              <div className="flex flex-wrap gap-6 text-sm text-white/40 font-bold uppercase tracking-widest">
                <div className="flex items-center gap-2"><Download size={16}/> {project.downloads} Downloads</div>
                <div className="flex items-center gap-2"><Star size={16} className="text-yellow-500"/> {project.stars} Stars</div>
                <div className="flex items-center gap-2"><Clock size={16}/> Updated {project.lastUpdate}</div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="prose prose-invert max-w-none">
            <p className="text-xl text-white/60 leading-relaxed italic">
              "{project.description}"
            </p>
          </div>

          {/* Action Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-8 border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-all group">
              <h3 className="font-black uppercase tracking-widest text-xs mb-6 flex items-center gap-2 text-cyan-500">
                <Download size={14}/> Primary Download
              </h3>
              <button className="w-full py-4 bg-white text-black font-black uppercase tracking-widest text-sm hover:bg-cyan-400 transition-all flex items-center justify-center gap-2">
                GET BINARY ({project.size})
              </button>
              <div className="mt-4 p-3 bg-black/50 border border-white/5 rounded font-mono text-[10px] text-white/40 break-all">
                <span className="text-cyan-500 font-bold">CHECKSUM:</span> {project.checksum}
              </div>
            </div>

            <div className="p-8 border border-white/5 bg-white/[0.02] flex flex-col justify-between">
              <div>
                <h3 className="font-black uppercase tracking-widest text-xs mb-4 flex items-center gap-2 text-purple-500">
                  <ShieldCheck size={14}/> Security Scan
                </h3>
                <p className="text-xs text-white/40 mb-6 font-bold uppercase">Escaneado por NebulaCore Sec. 0 amenazas detectadas.</p>
              </div>
              <button className="w-full py-4 border border-white/10 text-white font-black uppercase tracking-widest text-sm hover:border-purple-500 transition-all">
                VIEW FULL REPORT
              </button>
            </div>
          </div>

          {/* Documentation / Wiki Section */}
          <div className="space-y-8">
            <h2 className="text-3xl font-black uppercase italic flex items-center gap-4 italic tracking-tighter">
              <BookOpen className="text-cyan-500" /> System Wiki
            </h2>
            <div className="space-y-4">
              <WikiItem title="Instalación" content="Ejecuta el instalador como administrador y sigue los pasos en pantalla..." />
              <WikiItem title="Configuración de Alto Rendimiento" content="Para obtener el máximo rendimiento, activa el modo 'Overdrive' en los ajustes..." />
              <WikiItem title="Solución de Errores Comunes" content="Si la app no inicia, asegúrate de tener instalados los últimos drivers..." />
            </div>
          </div>
        </div>

        {/* Right Column: Community & Sidebar */}
        <div className="space-y-12">
          {/* Support / Donate */}
          <div className="p-8 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 rounded-3xl relative overflow-hidden group">
            <div className="relative z-10">
              <h3 className="text-2xl font-black uppercase italic mb-2 italic tracking-tighter">Support the Dev</h3>
              <p className="text-sm text-white/60 mb-6">Ayuda a mantener los servidores y el desarrollo de nuevas funciones.</p>
              <button className="px-6 py-3 bg-white text-black font-black uppercase tracking-widest text-xs hover:scale-105 transition-transform">
                BUY ME A COFFEE
              </button>
            </div>
            <div className="absolute top-1/2 right-[-20px] -translate-y-1/2 opacity-10 group-hover:rotate-12 transition-transform">
              <Star size={120} />
            </div>
          </div>

          {/* Local Chat for this project */}
          <div>
            <h3 className="text-xl font-black uppercase italic mb-6 tracking-tighter flex items-center gap-2">
              <MessageSquare size={20} className="text-cyan-500" /> Project Nexus
            </h3>
            <NexusChat />
          </div>

          {/* Project Specs */}
          <div className="p-8 border border-white/5 bg-white/[0.01]">
             <h4 className="font-black uppercase tracking-widest text-[10px] text-white/30 mb-6 italic">Technical Specifications</h4>
             <div className="space-y-4">
               <SpecRow label="Architecture" value="x64 / ARM64" />
               <SpecRow label="License" value="Proprietary" />
               <SpecRow label="Dependencies" value=".NET v8.0" />
               <SpecRow label="Repository" value="Private" />
             </div>
          </div>
        </div>

      </div>
    </div>
  );
}

function WikiItem({ title, content }: { title: string, content: string }) {
  return (
    <div className="border border-white/5 bg-white/[0.01] hover:bg-white/[0.03] transition-colors overflow-hidden">
      <div className="p-6 flex items-center justify-between cursor-pointer group">
        <h4 className="font-black uppercase tracking-widest text-sm italic group-hover:text-cyan-400 transition-colors">{title}</h4>
        <ChevronRight size={18} className="text-white/20 group-hover:text-cyan-500 transition-colors" />
      </div>
      <div className="px-6 pb-6 text-sm text-white/40 leading-relaxed border-t border-white/5 pt-4">
        {content}
      </div>
    </div>
  );
}

function SpecRow({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex justify-between items-center text-xs">
      <span className="font-bold text-white/20 uppercase tracking-widest">{label}</span>
      <span className="font-mono text-cyan-500">{value}</span>
    </div>
  );
}
