import React from 'react';
import { User, Shield, Star, Trophy, Download, MessageSquare, Zap, Terminal } from 'lucide-react';

export default function ProfilePage() {
  // Mock del usuario (esto vendría de NextAuth y Prisma)
  const user = {
    name: "Hacker_Pro_99",
    email: "hacker@nebula.core",
    level: 12,
    xp: 2450,
    nextLevelXp: 3000,
    joinDate: "2026-01-15",
    role: "ELITE TESTER",
    stats: {
      downloads: 45,
      comments: 12,
      bugsReported: 3
    }
  };

  const progress = (user.xp / user.nextLevelXp) * 100;

  return (
    <div className="min-h-screen bg-[#050505] text-white pt-32 pb-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* User ID Card */}
          <div className="lg:col-span-1 space-y-8">
            <div className="p-8 border border-cyan-500/20 bg-cyan-500/5 rounded-3xl relative overflow-hidden group">
              <div className="relative z-10 flex flex-col items-center text-center">
                <div className="w-32 h-32 bg-black border-2 border-cyan-500 rounded-full flex items-center justify-center mb-6 shadow-[0_0_40px_rgba(6,182,212,0.3)]">
                  <User size={64} className="text-cyan-500" />
                </div>
                <h2 className="text-3xl font-black uppercase italic tracking-tighter mb-1">{user.name}</h2>
                <span className="text-xs font-black text-cyan-500 uppercase tracking-[0.3em] mb-6">{user.role}</span>
                
                <div className="w-full space-y-2 mb-8">
                  <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-white/40">
                    <span>Level {user.level}</span>
                    <span>{user.xp} / {user.nextLevelXp} XP</span>
                  </div>
                  <div className="h-2 w-full bg-black rounded-full overflow-hidden border border-white/5">
                    <div className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400" style={{ width: `${progress}%` }}></div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 w-full">
                  <button className="py-3 border border-white/10 text-[10px] font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all">
                    Edit Profile
                  </button>
                  <button className="py-3 bg-white text-black text-[10px] font-black uppercase tracking-widest hover:bg-cyan-400 transition-all">
                    Inventory
                  </button>
                </div>
              </div>
              <div className="absolute top-0 right-0 p-4">
                 <Shield size={24} className="text-cyan-500/20" />
              </div>
            </div>

            {/* Achievement Matrix */}
            <div className="p-8 border border-white/5 bg-white/[0.02] rounded-3xl">
              <h3 className="text-sm font-black uppercase tracking-widest mb-6 flex items-center gap-2">
                <Trophy size={16} className="text-yellow-500" /> Achievements
              </h3>
              <div className="grid grid-cols-4 gap-4">
                <Badge active icon={<Zap size={18}/>} label="First Run" />
                <Badge active icon={<Download size={18}/>} label="Leecher" />
                <Badge icon={<MessageSquare size={18}/>} label="Chatter" />
                <Badge icon={<Star size={18}/>} label="Star" />
              </div>
            </div>
          </div>

          {/* Activity & Stats */}
          <div className="lg:col-span-2 space-y-12">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <StatItem icon={<Download/>} label="Downloads" value={user.stats.downloads} />
              <StatItem icon={<MessageSquare/>} label="Comments" value={user.stats.comments} />
              <StatItem icon={<Shield/>} label="Bugs Fixed" value={user.stats.bugsReported} />
            </div>

            {/* Activity Log */}
            <div className="space-y-6">
               <h3 className="text-2xl font-black uppercase italic tracking-tighter flex items-center gap-3 italic">
                 <Terminal className="text-cyan-500" /> Recent Activity Log
               </h3>
               <div className="border border-white/5 bg-black/50 font-mono text-xs overflow-hidden">
                 <LogEntry time="2026-02-01 14:20" msg="SYSTEM: Level Up! Level 12 reached." color="text-cyan-500" />
                 <LogEntry time="2026-02-01 12:05" msg="DOWNLOAD: Zenith Optimizer v2.1.0" />
                 <LogEntry time="2026-01-30 09:15" msg="XP_GAIN: +50 XP for daily login." color="text-yellow-500" />
                 <LogEntry time="2026-01-28 18:44" msg="COMMENT: Posted on Spanish Conquest 3D." />
               </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function Badge({ icon, label, active = false }: { icon: React.ReactNode, label: string, active?: boolean }) {
  return (
    <div className={`aspect-square rounded-xl flex flex-col items-center justify-center gap-1 transition-all border ${active ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)]' : 'bg-white/5 border-white/10 text-white/20'}`}>
      {icon}
      <span className="text-[6px] font-black uppercase tracking-tighter">{label}</span>
    </div>
  );
}

function StatItem({ icon, label, value }: { icon: React.ReactNode, label: string, value: number }) {
  return (
    <div className="p-8 border border-white/5 bg-white/[0.01] hover:border-cyan-500/20 transition-colors">
      <div className="flex items-center gap-3 text-white/40 mb-4 uppercase text-[10px] font-black tracking-widest">
        {icon} {label}
      </div>
      <div className="text-4xl font-black italic tracking-tighter">{value}</div>
    </div>
  );
}

function LogEntry({ time, msg, color = "text-white/40" }: { time: string, msg: string, color?: string }) {
  return (
    <div className="p-4 border-b border-white/5 flex gap-4 hover:bg-white/[0.02] transition-colors">
      <span className="text-white/20 shrink-0">[{time}]</span>
      <span className={`${color} font-bold uppercase`}>{msg}</span>
    </div>
  );
}
