import React from 'react';
import { Target, Zap, Clock, CheckCircle2, Construction } from 'lucide-react';

export default function RoadmapPage() {
  const milestones = [
    {
      title: "Nebula Core v1.0 Launch",
      status: "COMPLETED",
      desc: "Lanzamiento de la plataforma principal con chat y descargas seguras.",
      date: "Feb 2026",
      progress: 100
    },
    {
      title: "Spanish Conquest 3D: Raytracing Update",
      status: "IN_PROGRESS",
      desc: "Implementación de sombras en tiempo real y nuevos mapas de la península.",
      date: "March 2026",
      progress: 65
    },
    {
      title: "AI Optimizer Integration",
      status: "PLANNED",
      desc: "Añadiendo redes neuronales al optimizador para detectar patrones de lag.",
      date: "May 2026",
      progress: 10
    }
  ];

  return (
    <div className="min-h-screen bg-[#050505] text-white pt-32 pb-20 px-6">
      <div className="container mx-auto max-w-4xl">
        <header className="mb-20 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/20 rounded-full text-cyan-500 text-xs font-black uppercase tracking-widest mb-6">
            <Target size={14} /> Future Operations
          </div>
          <h1 className="text-6xl font-black uppercase italic tracking-tighter mb-4">Strategic <span className="text-cyan-500">Roadmap</span></h1>
          <p className="text-white/40 uppercase text-sm tracking-widest font-bold">Transparencia total en el desarrollo de software</p>
        </header>

        <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-white/10 before:to-transparent">
          {milestones.map((m, idx) => (
            <div key={idx} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
              {/* Icon / Dot */}
              <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-black text-cyan-500 z-10 shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-[0_0_20px_rgba(6,182,212,0.2)]">
                {m.status === "COMPLETED" ? <CheckCircle2 size={20} /> : m.status === "IN_PROGRESS" ? <Zap size={20} className="animate-pulse" /> : <Clock size={20} />}
              </div>

              {/* Content Card */}
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-8 border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-all group">
                <div className="flex justify-between items-start mb-4">
                  <span className="text-[10px] font-black uppercase tracking-widest text-cyan-500">{m.date}</span>
                  <span className={`text-[8px] font-black px-2 py-1 rounded border ${m.status === 'COMPLETED' ? 'border-green-500/50 text-green-500' : 'border-yellow-500/50 text-yellow-500'}`}>
                    {m.status}
                  </span>
                </div>
                <h3 className="text-xl font-black uppercase italic tracking-tighter mb-2 italic">{m.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed mb-6 font-medium">{m.desc}</p>
                
                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-white/20">
                    <span>Progress</span>
                    <span>{m.progress}%</span>
                  </div>
                  <div className="h-1 w-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-cyan-500 transition-all duration-1000" style={{ width: `${m.progress}%` }}></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
